﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using VarsityFoods2Go.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using VarsityFoods2Go.Data;
using VarsityFoods2Go.Utility;

namespace VarsityFoods2Go.Controllers
{
    [Area("Review")]
    public class ReviewsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public ReviewsController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Reviews
        [Authorize(Roles = SD.ManagerUser )]
        public async Task<IActionResult> AdminIndex()
        {
            var applicationDbContext = _context.Reviews.Include(r => r.MenuItem).Include(r => r.User);
            return View(await applicationDbContext.ToListAsync());
        }

        [Authorize]
        public async Task<IActionResult> Index()
        {
            //list of all reviews made by all users, wit respective food items
            var user = await _userManager.GetUserAsync(HttpContext.User);
            bool isAdmin = await _userManager.IsInRoleAsync(user, "Admin");

            if (isAdmin)
            {
                var allReviews = _context.Reviews.Include(r => r.MenuItem).Include(r => r.User).ToList();
                return View(allReviews);
            }
            else
            {
                var reviews = _context.Reviews.Include(r => r.MenuItem).Include(r => r.User)
                    .Where(r => r.User == user).ToList();
                return View(reviews);
            }
        }
        [AllowAnonymous]
        public async Task<IActionResult> ListAll()
        {
            //all reviews
            var reviews = await _context.Reviews.Include(r => r.MenuItem).Include(r => r.User).ToListAsync();
            return View(reviews);
        }
        private async Task<List<Reviews>> SortReviews(string sortBy, bool isDescending)
        {
            var reviewsList = _context.Reviews.Include(r => r.MenuItem).Include(r => r.User);
            IQueryable<Reviews> result;

            if (sortBy == null || sortBy == "")
            {
                result = reviewsList;
            }

            if (isDescending == false)
            {
                switch (sortBy.ToLower())
                {
                    case "Date":
                        result = reviewsList.OrderBy(x => x.Date);
                        break;
                    case "Rating":
                        result = reviewsList.OrderBy(x => x.Rating);
                        break;
                    case "Title":
                        result = reviewsList.OrderBy(x => x.Title);
                        break;
                    case "MenuItem name":
                        result = reviewsList.OrderBy(x => x.MenuItem.Name);
                        break;
                    default:
                        result = reviewsList.OrderBy(x => x.MenuItem.Id);
                        break;
                }
            }
            else
            {
                switch (sortBy.ToLower())
                {
                    case "Date":
                        result = reviewsList.OrderByDescending(x => x.Date);
                        break;
                    case "Rating":
                        result = reviewsList.OrderByDescending(x => x.Rating);
                        break;
                    case "Title":
                        result = reviewsList.OrderByDescending(x => x.Title);
                        break;
                    case "MenuItem name":
                        result = reviewsList.OrderByDescending(x => x.MenuItem.Name);
                        break;
                    default:
                        result = reviewsList.OrderByDescending(x => x.MenuItem.Id);
                        break;
                }
            }


            return await result.ToListAsync();
        }
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> AjaxListReviews(string sortBy, bool isDescending)
        {
            var listOfReviews = await SortReviews(sortBy, isDescending);

            return PartialView(listOfReviews);
        }

        [AllowAnonymous]
        public async Task<IActionResult> FoodReviews(int? foodId)
        {
            if (foodId == null)
            {
                return NotFound();
            }
            var food = _context.MenuItems.FirstOrDefault(x => x.Id == foodId);
            if (food == null)
            {
                return NotFound();
            }
            var reviews = await _context.Reviews.Include(r => r.MenuItem).Include(r => r.User).Where(x => x.MenuItem.Id == food.Id).ToListAsync();
            if (reviews == null)
            {
                return NotFound();
            }
            ViewBag.FoodName = food.Name;
            ViewBag.FoodId = food.Id;

            return View(reviews);
        }


        // GET: Reviews/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reviews = await _context.Reviews
                .Include(r => r.MenuItem)
                .Include(r => r.User)
                .SingleOrDefaultAsync(m => m.Id == id);
            if (reviews == null)
            {
                return NotFound();
            }

            return View(reviews);
        }

        // GET: Reviews/Create
        public IActionResult CreateWithFood(int? foodId)
        {
            var review = new Reviews();

            if (foodId == null)
            {
                return NotFound();
            }

            var food = _context.MenuItems.FirstOrDefault(p => p.Id == foodId);

            if (food == null)
            {
                return NotFound();
            }

            review.MenuItem = food;
            
            review.MenuItem.Id = food.Id;

            review.FoodId = food.Id;
            ViewData["FoodId"] = new SelectList(_context.MenuItems.Where(p => p.Id == foodId), "Id", "Name");
            var listOfNumbers = new List<int>() { 1, 2, 3, 4, 5 };
            var listOfRatings = listOfNumbers.Select(x => new { Id = x, Value = x.ToString() });
            ViewData["Rating"] = new SelectList(listOfRatings, "Id", "Value");

            return View(review);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateWithFood(int foodId, Reviews reviews)
        {
            if (foodId != reviews.FoodId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var userId = _userManager.GetUserId(HttpContext.User);
                reviews.UserId = userId;
                reviews.Date = DateTime.Now;
                reviews.MenuItem.Id = reviews.FoodId;


                _context.Add(reviews);
                await _context.SaveChangesAsync();
                return Redirect($"FoodReviews?foodId={foodId}");
            }
            var listOfNumbers = new List<int>() { 1, 2, 3, 4, 5 };
            var listOfRatings = listOfNumbers.Select(x => new { Id = x, Value = x.ToString() });
            ViewData["Rating"] = new SelectList(listOfRatings, "Id", "Value", reviews.Rating);
            ViewData["FoodId"] = new SelectList(_context.MenuItems.Where(p => p.Id == foodId), "Id", "Name", reviews.FoodId);
            return View(reviews);
        }


        // GET: Reviews/Create
        public IActionResult Create()
        {
           
            var listOfNumbers = new List<int>() { 1, 2, 3, 4, 5 };
            var listOfRatings = listOfNumbers.Select(x => new { Id = x, Value = x.ToString() });

            
            ViewData["Rating"] = new SelectList(listOfRatings, "Id", "Value");
            ViewData["FoodId"] = new SelectList(_context.MenuItems, "Id", "Name");
            return View();
        }

        // POST: Reviews/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,FoodReview,Rating,Date,FoodId,MenuItemId,UserId")] Reviews reviews)
        {
            if (ModelState.IsValid)
            {
                var userId = _userManager.GetUserId(HttpContext.User);
                var foodId = reviews.FoodId;

                reviews.UserId = userId;
               
               


                reviews.Date = DateTime.Now;
                _context.Add(reviews);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            var listOfNumbers = new List<int>() { 1, 2, 3, 4, 5 };
            var listOfRatings = listOfNumbers.Select(x => new { Id = x, Value = x.ToString() });
           
            ViewData["Rating"] = new SelectList(listOfRatings, "Id", "Value", reviews.Rating);
            ViewData["FoodId"] = new SelectList(_context.MenuItems, "Id", "Name", reviews.FoodId);
           
            return View(reviews);
        }

        // GET: Reviews/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reviews = await _context.Reviews.SingleOrDefaultAsync(m => m.Id == id);
            var user = await _userManager.GetUserAsync(HttpContext.User);
            var userRoles = await _userManager.GetRolesAsync(user);
            bool isAdmin = userRoles.Any(r => r == "Admin");

            if (reviews == null)
            {
                return NotFound();
            }

            if (isAdmin == false)
            {
                var userId = _userManager.GetUserId(HttpContext.User);
                if (reviews.UserId != userId)
                {
                    return BadRequest("You do not have permissions to edit this review.");
                }
            }
            var listOfNumbers = new List<int>() { 1, 2, 3, 4, 5 };
            var listOfRatings = listOfNumbers.Select(x => new { Id = x, Value = x.ToString() });
            ViewData["Rating"] = new SelectList(listOfRatings, "Id", "Value", reviews.Rating);
            ViewData["FoodId"] = new SelectList(_context.MenuItems, "Id", "Name", reviews.FoodId);
            return View(reviews);
        }


        // POST: Reviews/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,FoodReview,Rating,Date,FoodId,MenuItemId,UserId")] Reviews reviews)
        {
            if (id != reviews.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(reviews);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReviewsExists(reviews.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            var listOfNumbers = new List<int>() { 1, 2, 3, 4, 5 };
            var listOfRatings = listOfNumbers.Select(x => new { Id = x, Value = x.ToString() });
            ViewData["FoodId"] = new SelectList(_context.MenuItems, "Id", "Description", reviews.FoodId);
            ViewData["Rating"] = new SelectList(listOfRatings, "Id", "Value", reviews.Rating);
            return View(reviews);
        }

        // GET: Reviews/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reviews = await _context.Reviews
                .Include(r => r.MenuItem)
                .SingleOrDefaultAsync(m => m.Id == id);
            var user = await _userManager.GetUserAsync(HttpContext.User);
            var userRoles = await _userManager.GetRolesAsync(user);
            bool isAdmin = userRoles.Any(r => r == "Admin");

            if (reviews == null)
            {
                return NotFound();
            }

            if (isAdmin == false)
            {
                var userId = _userManager.GetUserId(HttpContext.User);
                if (reviews.UserId != userId)
                {
                    return BadRequest("You do not have permissions to edit this review.");
                }
            }

            return View(reviews);
        }

        // POST: Reviews/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reviews = await _context.Reviews.SingleOrDefaultAsync(m => m.Id == id);
            _context.Reviews.Remove(reviews);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReviewsExists(int id)
        {
            return _context.Reviews.Any(e => e.Id == id);
        }
    }
}

