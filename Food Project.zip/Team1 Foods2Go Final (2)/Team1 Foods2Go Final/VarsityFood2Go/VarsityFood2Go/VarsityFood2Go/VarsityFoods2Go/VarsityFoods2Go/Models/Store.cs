﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VarsityFoods2Go.Models
{
    public class Store
    {
        [Key]
        [Display(Name = "ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string ID { get; set; }

        [Required]
        [Display(Name = "Owner Name")]
        public string OwnerName { get; set; }

        [Required]
        [Display(Name = "Owner Email")]
        public string OwnerEmail { get; set; }

        [Required]
        [Display(Name = "Store Name")]
        public string StoreName { get; set; }

        [Display(Name = "Number of Roles")]
        public int RoleCount { get; set; }

        [Required]
        [Display(Name = "Number of Employees")]
        public int Employees { get; set; }
    }
}
