﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VarsityFoods2Go.Models
{
    public class Newsletter
    {
        [Key]
        [Display(Name = "Newsletter ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string NewsLetterID { get; set; }

        [Required]
        [Display(Name = "Title")]
        public string Title { get; set; }

        [Display(Name = "Newsletter Date")]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime NewsLetterDate { get; set; }

        [Required]
        [Display(Name = "Content")]
        public string Content { get; set; }

        [Display(Name = "Image Name")]
        public string ImageName { get; set; }

        [Required]
        [NotMapped]
        [Display(Name = "Image")]
        public IFormFile ImageFile { get; set; }
    }
}
