﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VarsityFoods2Go.Models
{
    public class Contact
    {
        [Key]
        [Display(Name = "Contact ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string ContactID { get; set; }

        [Required]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Comment")]
        public string Comment { get; set; }

        [Display(Name = "Response")]
        public string Response { get; set; }

        [Display(Name = "Comment Date")]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime CommentDate { get; set; }
    }
}
