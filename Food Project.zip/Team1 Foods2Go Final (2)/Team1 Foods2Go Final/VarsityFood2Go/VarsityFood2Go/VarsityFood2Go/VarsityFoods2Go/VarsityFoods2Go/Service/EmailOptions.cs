﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VarsityFoods2Go.Service
{
    public class EmailOptions
    {
        public string SendGridKey { get; set; }
    }
}
