using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VarsityFoods2Go.Data;
using VarsityFoods2Go.Utility;

namespace VarsityFoods2Go.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = SD.ManagerUser)]
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _db;

        public DashboardController(ApplicationDbContext context)
        {
            _db = context;
        }
        //Collects all the data from the database and adds to the Dashboard with the viewbags
        public IActionResult Index()
        {
            var customer = SD.CustomerEndUser.Count();
            var manager = SD.ManagerUser.Count();
            var orderData = _db.OrderHeaders.ToList();
            var menuData = _db.MenuItems.ToList();
            var TotalRevenue = _db.OrderDetails.Select(o => o.Price).Sum();
            var OrderCount = _db.OrderDetails.Select(o => o.Id).Count();
            var products = _db.OrderDetails.Select(p => p.Count).Sum();
            var orderAverage = OrderCount / 12;
            var RevenueAverage = TotalRevenue / 12;
            var RoundedAverage = Math.Round(RevenueAverage, 2);
            var product = _db.OrderDetails.Where(p => p.MenuItem.Name == "Beef Burger").Select(p => p.Count).Sum();
            var amount = _db.OrderDetails.Where(p => p.MenuItem.Name == "Beef Burger").Select(p => p.Price).Sum();
            ViewBag.ProductCount2 = _db.OrderDetails.Where(p => p.MenuItem.Name == "Steak Gatsby").Select(p => p.Count).Sum();
            ViewBag.ProductAmount2 = _db.OrderDetails.Where(p => p.MenuItem.Name == "Steak Gatsby").Select(p => p.Price).Sum();
            ViewBag.ProductCount3 = _db.OrderDetails.Where(p => p.MenuItem.Name == "Chicken Gatsby").Select(p => p.Count).Sum();
            ViewBag.ProductAmount3 = _db.OrderDetails.Where(p => p.MenuItem.Name == "Chicken Gatsby").Select(p => p.Price).Sum();
            ViewBag.ReviewCount = _db.Reviews.Select(r => r.Id).Count();
            ViewBag.CustomerCount = _db.Reviews.Select(r => r.UserId).Count();
            ViewBag.Stores = _db.Categories.Select(p => p.Name).Count();
            ViewBag.ProductAmount = amount;
            ViewBag.ProductCount = product;
            ViewBag.Product = products;
            ViewBag.TotalOrder = OrderCount;
            ViewBag.OrderAverage = orderAverage;
            ViewBag.Average = RoundedAverage;
            ViewBag.Sum = TotalRevenue;
            ViewBag.MenuItem = menuData;
            ViewBag.Date = orderData;
            ViewBag.Customers = customer;
            var users = _db.ApplicationUsers.Count();
            ViewBag.Users = users;
            return View();
        }
    }
}
